/*
 * CPE-555 Real-Time and Embedded Systems
 * Stevens Institute of Technology
 * Spring 2017
 *
 * FreeRTOS Template
 *
 * Name:
 */

/* Standard includes */
#include <stdio.h>

/* FreeRTOS includes */
#include "FreeRTOS.h"

/* global variables */
/* (Declare your global variables here) */

/* function prototypes */
/* (Add your function prototypes here) */

/* main application code */
int main( void )
{
	/* set STDOUT to be non-buffered to that printf() messages display immediately */
	setbuf(stdout, NULL);

	printf("Application started\n");

	/* (Add your application code here) */

	return 0;
}

/* (Add any additional function definitions here) */
